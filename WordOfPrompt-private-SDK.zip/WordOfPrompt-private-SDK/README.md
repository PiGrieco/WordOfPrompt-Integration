markdown
# Advllm SDK RecSys AgenticRag Multi-Agent Workflow GraphRAG

Advllm is a Python SDK for building recommendation systems for advertising based on language models. This SDK provides tools for interacting with various models and services, facilitating the creation of advertising pipelines for products, documents, and CSV files .

## Getting Started

To get started with Advllm, follow the steps below:

1. Install the SDK:

```bash
pip install advllm
```

### Features Tested with unietesting

- [x] Different LLM calling APIs OpenAI compatibility based-models in different versions such as Ollama (Llama, Alpaca, Vicuna, Llama 2 )  Mixtral , GPTs Sefl-Hosted LLM 
- [ ] Query Listening Stream Request AgenticRAG
- [x] Hugging Face Model Self-Hosted Inference APis calling 
- [x] Inference API Requetes OpenSesame Compute Intent-Score 
- [x] Configure Self-Hosted APIs Text-Generation (ollama)
- [x] OpenAI-like interface using [llm-api-python](https://ollama.com/blog/openai-compatibility)
- [ ] handling Exceptions Requests Status Erros Faild Network Semd Data TCP 



### Compute Intention user buying 

Create a configuration file named config.json to access the PiGrieco/OpenSesame fine-tuned version, which computes the score of intention to buy based on user prompts. Obtain the API token by requesting access via email:

```json

{
    "model_id": "PiGrieco/OpenSesame",
    "api_token": "hf_XXXXXXXX"
}
```

1. Initialize the OpenSesameAPI class with the configuration and send queries to the OpenSeamo model:

```python

from advllm.openseamo import OpenSeamoAPI
from advllm.config import ConfigHF

# Option 1: Directly hardcode parameters in Config
# model_id = "PiGrieco/OpenSesame"
# api_token = "hf_XXXXXXXX"
# config = ConfigHF(model_id, api_token)

# Option 2: Load parameters from JSON file
config = ConfigHF.from_json("config.json")

openseamo_model = OpenSeamoAPI(config)

prompt = "I am interested in purchasing an iPhone 12 around $700, red, 64GB, Germanyo "
result = openseamo_model.query(prompt)
print("Model response:", result)

```

### Self-Hosted LLM Private Model 

Create a PromptFactory instance with customized prompt messages:

#####  CURL Example of any Host LLM 


```YAML

curl --location "https://api.mistral.ai/v1/chat/completions" \
     --header 'Content-Type: application/json' \
     --header 'Accept: application/json' \
     --header "Authorization: Bearer $MISTRAL_API_KEY" \
     --data '{
    "model": "mistral-large-latest",
    "messages": [
     {
        "role": "user",
        "content": "What is the best French cheese?"
      }
    ]
  }'


```
**usage**

```python
import requests
from advllm.config import ConfigLLM
from advllm.self_hosted_llm_requester import SelfHostedLLMRequester
from advllm.prompt_factory import PromptFactory

base_url = 'https://api.mistral.ai/v1/chat/completions'
headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': f'Bearer {MISTRAL_API_KEY}'  # Make sure to replace MISTRAL_API_KEY with your actual API key
}
model_name = 'mistral-large-latest'
question_content = "What is the best French cheese?"
factory = PromptFactory(question=question_content)
prompt_messages = factory.generate_prompt()
config = ConfigLLM(base_url=base_url, headers=headers, prompt=prompt_messages)
requester = SelfHostedLLMRequester(config)
payload = config,Prompt(model_name=model_name)
response = requester.send_request(payload)
print(response)
```

### PromptAnalyzer 

The `PromptAnalyzer` class allows you to analyze prompts, extract keywords, and determine the intent of the prompt using a pre-trained zero-shot model.


**Set the config Depends on Optiona**
```json

{
    "model_id": "PiGrieco/OpenSesame",
    "api_token": "hf_XXXXXXXX"
}
```

```python 
from advllm.prompt_analyzer import PromptAnalyzer
from advllm.clients.inference_client import ConfigHF


prompt = "searching at amazon to check what is the most relevant product"

config = ConfigHF.from_json("config.json")

prompt_analyzer = PromptAnalyzer(config, keywords_extracted=True)
is_match, keywords, intent_score, orignal_prompt  = prompt_analyzer.analyze_prompt(prompt)

print("Prompt Analysis Result:")
print(f"Is intent to buy: {is_match}")
print(f"Keywords: {keywords}")
print(f"Intent Score: {intent_score:.2f}")
print(f"Orignal Prompt: {orignal_prompt}")

   
```


### Listen to the Prompt Self-Hosted LLM :

let us expain the how we do listen to your User's message and pass into out Services 


here `Curl-APIs use case Ollam OpenAI Compability` 

```YAML 
curl http://localhost:11434/v1/chat/completions \
    -H "Content-Type: application/json" \
    -d '{
        "model": "llama2",
        "messages": [
            {
                "role": "system",
                "content": "You are a helpful assistant."
            },
            {
                "role": "user",
                "content": "Hello!"
            }
        ]
    }'
```

1 . **SelfHostedLLMWebsocketServer** used WebSocket Listener to your host LLM request 

here the Use case of listen to the Prompt :

```python 

ws = websockets.connect(ws_url)

        while True:
            data = ws.recv()

            message_dict = json.loads(data)

            message = message_dict.get("content", "")

            processed_message = process_message_fn(message)

            payload = {
                "model": self.model,
                "messages": [
                    {
                        "role": "user",
                        "content": processed_message
                    }
                ]
            }


```

```python
import json
import websockets
import threading

from self_hosted_llm_requester import SelfHostedLLMWebsocketServer

def process_message(message):
    print(message)
    return message

# main function to start the WebSocket server
def Listener():
    base_url = "http://localhost:11434"

    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }

    model = "llama2"

    
    llm_requester = SelfHostedLLMWebsocketServer(base_url, headers, model)

    # convert the base URL from HTTP to WebSocket
    ws_url = base_url.replace("http://", "ws://")

    # start the WebSocket server using the built-in start_websocket_server method
    llm_requester.start_websocket_server(process_message_fn=process_message)
    print(f"WebSocket server is running on URL {ws_url}")

if __name__ == "__main__":
    # start the WebSocket server
    Listener()

```